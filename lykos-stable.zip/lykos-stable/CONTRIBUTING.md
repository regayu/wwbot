Please submit all pull requests to the `master` branch.
If you are reporting an issue, please make sure you are on the latest `master`
or the newest `stable` branch (it may have a number suffix, e.g. `stable-42`).
